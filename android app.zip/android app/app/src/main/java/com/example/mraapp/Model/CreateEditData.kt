package com.example.mraapp.Model

import com.google.gson.annotations.SerializedName

data class CreateEditData(
    @SerializedName("TPIN") val taxpayerTpin:String?,
    @SerializedName("BusinessCertificateNumber")val taxpayerBusinessCertificateNumber:String?,
    @SerializedName("TradingName")val taxpayerTradingName:String?,
    @SerializedName("BusinessRegistrationDate")val taxpayerBusinessRegistrationDate:String?,
    @SerializedName("MobileNumber")val taxpayerMobileNumber:String?,
    @SerializedName("Email")val taxpayerEmail:String?,
    @SerializedName("PhysicalLocation")val taxpayerPhysicalLocation:String?,
    @SerializedName("Username")val taxpayerUsername:String?
)
