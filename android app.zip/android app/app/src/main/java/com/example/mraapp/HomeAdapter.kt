package com.example.mraapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HomeAdapter(
    private val homeList:List<HomeItem>,
    private val listener:OnLongItemClickListener) :RecyclerView.Adapter<HomeAdapter.HomeViewHolder>()  {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeViewHolder {
        val itemView=LayoutInflater.from(parent.context).inflate(R.layout.home_item,parent,false)
        return HomeViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: HomeViewHolder, position: Int) {
        val currentItem=homeList[position]

        holder.imageView.setImageResource(currentItem.imageResource)
        holder.textView1.text=currentItem.textTpinVal
        holder.textView2.text=currentItem.textEmailVal
        holder.textView3.text=currentItem.textTradingNameVal
        holder.textView4.text=currentItem.textPhoneNumberVal
        holder.textView5.text=currentItem.textLocationVal
        holder.textView6.text=currentItem.textBusinessCertificationNumberVal
        holder.textView7.text=currentItem.textDateOfRegistrationVal

    }

    override fun getItemCount()=homeList.size

    inner class HomeViewHolder(itemView: View):RecyclerView.ViewHolder(itemView),View.OnLongClickListener{

       val imageView:ImageView=itemView.findViewById(R.id.image_view)
       val textView1: TextView=itemView.findViewById(R.id.tpinPlace)
       val textView2: TextView=itemView.findViewById(R.id.emailPlace)
       val textView3: TextView=itemView.findViewById(R.id.tradingNamePlace)
       val textView4: TextView=itemView.findViewById(R.id.phoneNumberPlace)
       val textView5: TextView=itemView.findViewById(R.id.locationPlace)
       val textView6: TextView=itemView.findViewById(R.id.businessCertificationNumberPlace)
       val textView7: TextView=itemView.findViewById(R.id.dateOfRegistrationPlace)


       init {
           itemView.setOnLongClickListener(this)
       }

        override fun onLongClick(v: View?): Boolean {
            val position=bindingAdapterPosition
            if (position!=RecyclerView.NO_POSITION) {
                listener.onLongItemClick(position,homeList[position])
            }
            return true
        }
    }
    interface OnLongItemClickListener{

        fun onLongItemClick(position: Int, currentList: HomeItem)

    }
}