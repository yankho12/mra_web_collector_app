package com.example.mraapp

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.example.mraapp.databinding.ActivityNavigationDrawerBinding
import com.example.mraapp.databinding.FragmentHomeBinding
import com.example.mraapp.databinding.NavHeaderBinding
import com.google.android.material.navigation.NavigationView

class NavigationDrawer : AppCompatActivity() {

    lateinit var  toggle: ActionBarDrawerToggle
    lateinit var drawerLayout: DrawerLayout
    lateinit var userID: String
    lateinit var firstName: String
    lateinit var lastName: String
    lateinit var fullName: String


    private lateinit var binding: ActivityNavigationDrawerBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNavigationDrawerBinding.inflate(layoutInflater)

        setContentView(binding.root)


        //setContentView(R.layout.activity_navigation_drawer)

        drawerLayout =findViewById(R.id.drawerLayout)
        val navView: NavigationView =findViewById(R.id.nav_view)

        //below we bind to header for the navigation instance used
        val headerView=navView.getHeaderView(0)
        val headerViewBinding=NavHeaderBinding.bind(headerView)
        userID= intent.getStringExtra("UserID").toString()
        firstName= intent.getStringExtra("firstName").toString()
        lastName= intent.getStringExtra("lastName").toString()
        fullName="$firstName $lastName"
        headerViewBinding.userEmailId.text=userID
        headerViewBinding.userNameId.text=fullName

        //val headerView: Navigation= findViewById(R.id.headerID)
        toggle= ActionBarDrawerToggle(this, drawerLayout,R.string.open,R.string.close)

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        replaceFragment(HomeFragment(),"Home")//default fragment on login
        navView.setNavigationItemSelectedListener {

            it.isChecked=true

            when(it.itemId){

                R.id.nav_home->replaceFragment(HomeFragment(),it.title.toString())
                R.id.nav_new_taxpayer->replaceFragment(CreateTaxpayerFragment(),it.title.toString())
                R.id.nav_contant_us-> Toast.makeText(applicationContext,"Feature coming soon", Toast.LENGTH_SHORT).show()
                R.id.nav_help-> Toast.makeText(applicationContext,"Feature coming soon", Toast.LENGTH_SHORT).show()
                R.id.nav_logout-> logoutFunction()


            }


            true
        }

    }
    private fun logoutFunction(){
        startActivity(Intent(this@NavigationDrawer,MainActivity::class.java))
        finish()

    }
     private fun replaceFragment(fragment: Fragment, title: String){
         //add userID to fragment arguments before replacing
         val mBundle= Bundle()
         mBundle.putString("userID",userID)
         fragment.arguments=mBundle
        //replace fragment below
        val fragmentManager=supportFragmentManager
        val fragmentTransaction=fragmentManager.beginTransaction()
         fragmentTransaction.replace(R.id.frameLayout,fragment)
         fragmentTransaction.addToBackStack(null)
         fragmentTransaction.commit()
        drawerLayout.closeDrawers()
        setTitle(title)
    }
    fun reloadHomeFragment(fragment: Fragment, title: String){
        val fragmentManager=supportFragmentManager
        val fragmentTransaction=fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frameLayout,fragment)
        fragmentTransaction.detach(fragment)
        fragmentTransaction.attach(fragment)
        fragmentTransaction.commit()
        drawerLayout.closeDrawers()
        setTitle(title)

    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if(toggle.onOptionsItemSelected(item)){

            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
