package com.example.mraapp

data class HomeItem(val imageResource: Int, val textTpinVal:String, val textEmailVal:String, val textTradingNameVal:String, val textLocationVal:String, val textPhoneNumberVal:String, val textBusinessCertificationNumberVal:String, val textDateOfRegistrationVal:String)