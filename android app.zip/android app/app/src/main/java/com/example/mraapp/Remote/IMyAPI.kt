package com.example.mraapp.Remote

import com.example.mraapp.MainActivity
import com.example.mraapp.Model.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import org.json.JSONArray
import retrofit2.Call
import retrofit2.http.*

interface IMyAPI {


    fun registerUser(@Field("name")name:String, @Field("email")email:String, @Field("password")password:String): Call<APIResponse>


    @Headers("Content-Type:application/json",
        "userid:*****",
        "apikey:*******")
    @POST("*******")
    fun loginUser(@Body userLogIn:MainActivity.UserData): Call<APIResponse>

    @Headers("Content-Type:application/json",
        "userid:*******",
        "apikey:*******")
    @GET("*******")
    fun getTaxpayers(): Call<List<GetAllTaxpayersAPIResponse>>

    @Headers("Content-Type:application/json",
        "userid:*******",
        "apikey:*******")
    @POST("*******")
    fun createTaxpayer(@Body createTaxpayerDetails:CreateEditData): Call<CreateTaxpayerAPIResponse>


    @Headers("Content-Type:application/json",
        "userid:*******",
        "apikey:*******")
    @POST("*******")
    fun editTaxpayer(@Body editTaxpayerDetails:CreateEditData): Call<EditTaxpayerAPIResponse>

    @Headers("Content-Type:application/json",
        "userid:*******",
        "apikey:*******")
    @POST("*******")
    fun deleteTaxpayer(@Body deleteTpinValue:DeleteTaxpayerData): Call<DeleteTaxpayerAPIResponse>



}