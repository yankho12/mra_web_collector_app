package com.example.mraapp.Common


import com.example.mraapp.Remote.IMyAPI
import com.example.mraapp.Remote.RetrofitClient

object Common {
    val BASE_URL="*******"
    val api: IMyAPI
        get()= RetrofitClient.getClient(BASE_URL).create(IMyAPI::class.java)

}