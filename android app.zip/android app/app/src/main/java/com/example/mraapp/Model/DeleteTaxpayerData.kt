package com.example.mraapp.Model

import com.google.gson.annotations.SerializedName

data class DeleteTaxpayerData(
    @SerializedName("TPIN") val taxpayerTpin:String?
)
