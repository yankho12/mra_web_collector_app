package com.example.mraapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.mraapp.Common.Common
import com.example.mraapp.Model.APIResponse
import com.example.mraapp.Remote.IMyAPI
import com.example.mraapp.databinding.ActivityRegisterBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding

    internal lateinit var mService: IMyAPI

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_register)

        //initialize the service
        mService= Common.api

        //event listener
        binding.txtLogin.setOnClickListener { startActivity(Intent(this@RegisterActivity,MainActivity::class.java)) }

        binding.btnRegister.setOnClickListener { Toast.makeText(this@RegisterActivity,"registered successfully now you can log in", Toast.LENGTH_SHORT).show() }
        //enable below to actually register with webservice
        //btn_register.setOnClickListener { createNewUser(name.text.toString(),email.text.toString(),password.text.toString()) }
    }

    private fun createNewUser(name: String, email: String, password: String) {
        mService.registerUser(name,email,password)
            .enqueue(object: Callback<APIResponse>{
                override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                    Toast.makeText(this@RegisterActivity,t.message, Toast.LENGTH_SHORT).show()

                }

                override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                    if(response.body()!!.Authenticated==true)
                        Toast.makeText(this@RegisterActivity,response.body()!!.Remark,Toast.LENGTH_SHORT).show()
                    else
                        Toast.makeText(this@RegisterActivity,"register successfully",Toast.LENGTH_SHORT).show()
                }

            })

    }
}
