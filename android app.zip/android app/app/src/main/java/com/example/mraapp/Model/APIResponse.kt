package com.example.mraapp.Model
//APIResponse is used for user authentication
class APIResponse {
    //var error:Boolean=false
    //var uid:String?=null
    //var error_msg:String?=null
    //var user :User?=null

    var ResultCode:Int?=1
    var Remark: String?=null
    var Token:HashMap<String, String> ?=null
    var Authenticated:Boolean?=false
    var UserDetails:HashMap<String, String> ?=null


}