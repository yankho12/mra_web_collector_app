package com.example.mraapp

import android.os.Bundle
import android.text.Editable
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.mraapp.Common.Common
import com.example.mraapp.Model.CreateEditData
import com.example.mraapp.Model.CreateTaxpayerAPIResponse
import com.example.mraapp.Remote.IMyAPI
import com.example.mraapp.databinding.FragmentCreateTaxpayerBinding
import com.example.mraapp.databinding.NavHeaderBinding
import com.google.android.material.navigation.NavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [CreateTaxpayerFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class CreateTaxpayerFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private lateinit var binding: FragmentCreateTaxpayerBinding
    private lateinit var userID: String
    private var fragmentCreateTaxpayerBinding:FragmentCreateTaxpayerBinding?=null
    private  var mService: IMyAPI = Common.api

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= FragmentCreateTaxpayerBinding.inflate(layoutInflater)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        fragmentCreateTaxpayerBinding = FragmentCreateTaxpayerBinding.inflate(inflater, container, false)
        val view = binding.root
        return view

        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_create_taxpayer, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        emailFocusListener()
        tradingNameFocusListener()
        locationFocusListener()
        phoneNumberFocusListener()
        businessCertificationNumberFocusListener()
        dateOfRegistrationFocusListener()
        tPinFocusListener()
        binding.createTaxpayerButton.setOnClickListener {
            Toast.makeText(activity,"validating details", Toast.LENGTH_SHORT).show()
            validateDetails()

        }
        //get user id from fragment replace in nav drawer
        val bundle=arguments
        userID= bundle!!.getString("userID").toString()

    }

    private fun createTaxpayerTOAPI() {
        val createTaxpayerDetails=CreateEditData(
            taxpayerTpin = binding.tPinEditText.text.toString(),
            taxpayerBusinessCertificateNumber =binding.businessCertificationNumberEditText.text.toString(),
            taxpayerTradingName = binding.tradingNameEditText.text.toString(),
            taxpayerBusinessRegistrationDate = binding.dateOfRegistrationEditText.text.toString(),
            taxpayerMobileNumber = binding.phoneNumberEditText.text.toString(),
            taxpayerEmail = binding.emailEditText.text.toString(),
            taxpayerPhysicalLocation = binding.locationEditText.text.toString(),
            taxpayerUsername = userID)


        mService.createTaxpayer(createTaxpayerDetails)
            .enqueue(object :Callback<CreateTaxpayerAPIResponse>{
                override fun onResponse(
                    call: Call<CreateTaxpayerAPIResponse>,
                    response: Response<CreateTaxpayerAPIResponse>
                ) {
                    when(response.code().toString()){
                        "200"-> Toast.makeText(activity,"taxpayer successfully created", Toast.LENGTH_SHORT).show()
                        "300"-> Toast.makeText(activity,"taxpayer already exists", Toast.LENGTH_SHORT).show()
                        "400"-> Toast.makeText(activity,"username does not exist", Toast.LENGTH_SHORT).show()
                        "500"-> Toast.makeText(activity,"internal server error", Toast.LENGTH_SHORT).show()

                        else ->Toast.makeText(activity,"unable to add new taxpayer", Toast.LENGTH_SHORT).show()
                    }

                    //if (response.code()==200){
                    //    Toast.makeText(activity,"taxpayer successfully created", Toast.LENGTH_SHORT).show()
                    //}
                    //if (response.code()==300){
                   //     Toast.makeText(activity,"taxpayer already exists", Toast.LENGTH_SHORT).show()
                    //}
                    //if (response.code()==400){
                   //     Toast.makeText(activity,"username does not exist", Toast.LENGTH_SHORT).show()
                    //}
                   //if (response.code()==500){
                       // Toast.makeText(activity,"internal server error", Toast.LENGTH_SHORT).show()
                    //}
                    //else{
                    //    Toast.makeText(activity,"unable to add new taxpayer", Toast.LENGTH_SHORT).show()
                    //}
                }

                override fun onFailure(call: Call<CreateTaxpayerAPIResponse>, t: Throwable) {
                    Toast.makeText(activity,t.message, Toast.LENGTH_SHORT).show()
                }

            })


    }

    private fun emailFocusListener() {
        //Toast.makeText(activity,"4444444444", Toast.LENGTH_SHORT).show()
        //binding.emailEditText.setOnClickListener { Toast.makeText(activity,"clicked", Toast.LENGTH_SHORT).show() }

        binding.emailEditText.setOnFocusChangeListener { _, focused ->
            if (!focused)
            {

                binding.emailContainer.helperText=validEmail()

            }

        }
    }

    private fun validEmail(): String? {
        val emailText=binding.emailEditText.text.toString()

        if (!Patterns.EMAIL_ADDRESS.matcher(emailText).matches())
        {

            return "The email is invalid"
        }
        return null

    }
    private fun tradingNameFocusListener() {
        binding.tradingNameEditText.setOnFocusChangeListener { _, focused ->
            if (!focused)
            {
                val tradingNameText=binding.tradingNameEditText.text.toString()
                if (!tradingNameText.isNullOrEmpty()){
                    binding.tradingNameContainer.helperText=null
                } else{
                    binding.tradingNameContainer.helperText="trading name must not be empty"
                }


            }

        }
    }

    private fun locationFocusListener() {
        binding.locationEditText.setOnFocusChangeListener { _, focused ->
            if (!focused)
            {
                val locationText=binding.locationEditText.text.toString()
                if (!locationText.isNullOrEmpty()){
                    binding.locationContainer.helperText=null
                } else{
                    binding.locationContainer.helperText="location must not be empty"
                }


            }

        }
    }

    private fun phoneNumberFocusListener() {
        binding.phoneNumberEditText.setOnFocusChangeListener { _, focused ->
            if (!focused)
            {

                binding.phoneNumberContainer.helperText=validPhoneNumber()

            }

        }
    }

    private fun validPhoneNumber(): String? {
        val phoneNumberText=binding.phoneNumberEditText.text.toString()

        if (!phoneNumberText.matches(".*[0-9].*.".toRegex()))
        {

            return " use format eg:0991447495"
        }
        if (phoneNumberText.length!=10){
            return "must be 10 digits (format:0991447495)"
        }

        return null

    }

    private fun businessCertificationNumberFocusListener() {
        binding.businessCertificationNumberEditText.setOnFocusChangeListener { _, focused ->
            if (!focused)
            {
                val businessCertificationNumberText=binding.businessCertificationNumberEditText.text.toString()
                if (!businessCertificationNumberText.isNullOrEmpty()){
                    binding.businessCertificationNumberContainer.helperText=null
                } else{
                    binding.businessCertificationNumberContainer.helperText="Business certification number must not be empty"
                }


            }

        }
    }

    private fun dateOfRegistrationFocusListener() {
        binding.dateOfRegistrationEditText.setOnFocusChangeListener { _, focused ->
            if (!focused)
            {
                val dateOfRegistrationText=binding.dateOfRegistrationEditText.text.toString()

                if (dateOfRegistrationText.isNullOrEmpty()){
                    binding.dateOfRegistrationContainer.helperText="date must not be empty format(year/month/day) eg:2021/11/02"
                }
                else if (dateOfRegistrationText.length==10 ){
                    if (dateOfRegistrationText[4].toString()=="/" && dateOfRegistrationText[7].toString()=="/" ){
                        binding.dateOfRegistrationContainer.helperText=null
                    } else{
                        binding.dateOfRegistrationContainer.helperText="use proper format(year/month/day) eg:2021/11/02"
                    }



                }else{

                    binding.dateOfRegistrationContainer.helperText="use proper format(year/month/day) eg:2021/11/02"
                }



            }

        }
    }

    private fun tPinFocusListener() {
        binding.tPinEditText.setOnFocusChangeListener { _, focused ->
            if (!focused)
            {

                binding.tPinContainer.helperText=validTPin()

            }

        }
    }

    private fun validTPin(): String? {
        val tPinText=binding.tPinEditText.text.toString()

        if (!tPinText.matches(".*[0-9].*.".toRegex()))
        {

            return "Digits only required"
        }
        if (tPinText.length !=8){
            return "Tpin must be 8 digits"
        }

        return null

    }

    private fun validateDetails() {


        val emailText=binding.emailEditText.text.toString()
        if (!Patterns.EMAIL_ADDRESS.matcher(emailText).matches())
        {

            binding.emailContainer.helperText="The email is invalid"
        }else{
            binding.emailContainer.helperText=null
        }


        val tradingNameText=binding.tradingNameEditText.text.toString()
        if (!tradingNameText.isNullOrEmpty()){
            binding.tradingNameContainer.helperText=null
        }else{
            binding.tradingNameContainer.helperText="trading name must not be empty"
        }


        val locationText=binding.locationEditText.text.toString()
        if (!locationText.isNullOrEmpty()){
            binding.locationContainer.helperText=null
        } else{
            binding.locationContainer.helperText="location must not be empty"
        }


        val phoneNumberText=binding.phoneNumberEditText.text.toString()
        if (!phoneNumberText.matches(".*[0-9].*.".toRegex()))
        {
            binding.phoneNumberContainer.helperText="Digits only required(format:0991447495)"
        }
        if (phoneNumberText.length!=10){
            binding.phoneNumberContainer.helperText="must be 10 digits (format:0991447495)"
        }
        else{
            binding.phoneNumberContainer.helperText=null
        }


        val businessCertificationNumberText=binding.businessCertificationNumberEditText.text.toString()
        if (!businessCertificationNumberText.isNullOrEmpty()){
            binding.businessCertificationNumberContainer.helperText=null
        } else{
            binding.businessCertificationNumberContainer.helperText="Business certification number must not be empty"
        }


        val dateOfRegistrationText=binding.dateOfRegistrationEditText.text.toString()

        if (dateOfRegistrationText.isNullOrEmpty()){
            binding.dateOfRegistrationContainer.helperText="date must not be empty format(year/month/day) eg:2021/11/02"
        }
        else if (dateOfRegistrationText.length==10 ){
            if (dateOfRegistrationText[4].toString()=="/" && dateOfRegistrationText[7].toString()=="/" ){
                binding.dateOfRegistrationContainer.helperText=null
            } else{
                binding.dateOfRegistrationContainer.helperText="use proper format(year/month/day) eg:2021/11/02"
            }
        }else{
            binding.dateOfRegistrationContainer.helperText="use proper format(year/month/day) eg:2021/11/02"
        }



        val tPinText=binding.tPinEditText.text.toString()
        if (!tPinText.matches(".*[0-9].*.".toRegex()))
        {

            binding.tPinContainer.helperText="Digits only required"
        }
        if (tPinText.length !=8){
            binding.tPinContainer.helperText= "Tpin must be 8 digits"
        }else{
            binding.tPinContainer.helperText=null
        }
        // after running validation above the below takes helpertexxt values again to see if valid and then intiate
        // adding to server with createTaxpayerTOAPI()
        var t1=binding.businessCertificationNumberContainer.helperText
        var t2=binding.tPinContainer.helperText
        var t3=binding.emailContainer.helperText
        var t4=binding.tradingNameContainer.helperText
        var t5=binding.locationContainer.helperText
        var t6=binding.dateOfRegistrationContainer.helperText
        var t7=binding.phoneNumberContainer.helperText

        if (t1==null && t2==null && t3==null&& t4==null&& t5==null&& t6==null&& t7==null ){

            createTaxpayerTOAPI()

        }else{
            Toast.makeText(activity,"provide proper details  please", Toast.LENGTH_SHORT).show()
        }

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment CreateTaxpayerFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            CreateTaxpayerFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }

            }
    }
}