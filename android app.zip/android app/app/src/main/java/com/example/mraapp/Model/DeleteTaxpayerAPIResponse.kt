package com.example.mraapp.Model

class DeleteTaxpayerAPIResponse {

}