package com.example.mraapp.Model

class CreateTaxpayerAPIResponse {
    var TPIN:String?="00000000"
    var Email:String?="00000000"
    var MobileNumber:String?="00000000"
    var PhysicalLocation:String?="00000000"
    var BusinessCertificateNumber:String?="00000000"
    var TradingName:String?="00000000"
    var BusinessRegistrationDate:String?="00000000"
    var Username:String?="000000"
}