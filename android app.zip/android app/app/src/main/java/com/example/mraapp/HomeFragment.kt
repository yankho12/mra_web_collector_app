package com.example.mraapp


import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mraapp.Common.Common
import com.example.mraapp.Model.*
import com.example.mraapp.Remote.IMyAPI
import com.example.mraapp.databinding.ActivityNavigationDrawerBinding
import com.example.mraapp.databinding.FragmentHomeBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.example.mraapp.databinding.FragmentEditTaxpayerBinding
import com.example.mraapp.databinding.NavHeaderBinding
import com.google.android.material.navigation.NavigationView
import com.google.android.material.textfield.TextInputEditText
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [HomeFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class HomeFragment : Fragment(),HomeAdapter.OnLongItemClickListener {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private lateinit var binding: FragmentHomeBinding
    private var fragmentHomeBinding: FragmentHomeBinding?=null
    private lateinit var bindingEdit: FragmentEditTaxpayerBinding

    //private lateinit var mService: IMyAPI
    private  var mService: IMyAPI=Common.api
    private lateinit var userID :String


    private var homeList=generateList()
    private var adapter=HomeAdapter(homeList,this)
    //private lateinit var adapter: HomeAdapter



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding= FragmentHomeBinding.inflate(layoutInflater)
        bindingEdit= FragmentEditTaxpayerBinding.inflate(layoutInflater)

        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //savedInstanceState?.isEmpty
        fragmentHomeBinding = FragmentHomeBinding.inflate(inflater, container, false)

        var view=binding.root
        return view
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_home, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Toast.makeText(activity,"loading...", Toast.LENGTH_SHORT).show()
        refreshHomePageData()

        binding.swipeRefreshId.setOnRefreshListener {
           // Toast.makeText(activity,"enter on refreshlisteer", Toast.LENGTH_SHORT).show()
            if (binding.swipeRefreshId.isRefreshing){
               pullRefreshLayoutData()
                binding.swipeRefreshId.isRefreshing=false
            }



        }

        //get user id from fragment replace in nav drawer
        val bundle=arguments
        userID= bundle!!.getString("userID").toString()
        //Toast.makeText(activity,userID, Toast.LENGTH_SHORT).show()






    }

    private fun refreshHomePageData() {
        binding.swipeRefreshId.isRefreshing=true

        Handler(Looper.getMainLooper()).postDelayed({

        binding.recyclerView.layoutManager=LinearLayoutManager(activity)
            //Toast.makeText(activity,"set up layout manager", Toast.LENGTH_SHORT).show()

        binding.recyclerView.adapter=HomeAdapter(homeList,this)
            //Toast.makeText(activity,"set up home adapter", Toast.LENGTH_SHORT).show()

        },2000)

        Handler(Looper.getMainLooper()).postDelayed({
            binding.swipeRefreshId.isRefreshing=false

        },1000)
    }

    private fun pullRefreshLayoutData() {
        val listSize=homeList.size
        binding.recyclerView.adapter?.notifyItemRangeRemoved(0,listSize)
        homeList=generateList()
        Handler(Looper.getMainLooper()).postDelayed({
            binding.recyclerView.layoutManager=LinearLayoutManager(activity)
            //Toast.makeText(activity,"generated list in onrefresh", Toast.LENGTH_SHORT).show()

            binding.recyclerView.adapter=HomeAdapter(homeList,this)
            //Toast.makeText(activity,"finished notifiydatasetchanged", Toast.LENGTH_SHORT).show()

        },2000)


    }


    override fun onLongItemClick(position: Int,currentList: HomeItem) {
        showAlertDialog(requireView(),currentList)
        adapter.notifyItemChanged(position)
    }

    private fun showAlertDialog(view: View,currentList: HomeItem){
        var currentTpin=currentList.textTpinVal
        MaterialAlertDialogBuilder(requireActivity())
            .setTitle("More")
            .setMessage("Choose weather you want to edit or delete taxpayer with TPin: $currentTpin")
            .setNegativeButton("Edit"){dialog,which->

                //Toast.makeText(activity,"edit clicked", Toast.LENGTH_SHORT).show()


                editTaxpayerPage(requireView(),currentList)

            }
            .setPositiveButton("Delete"){dialog,which->
                confirmDelete(requireView(),currentList)

            }
            .show()


    }

    private fun editTaxpayerPage(view: View, currentList: HomeItem){


        val curTpin=currentList.textTpinVal
        val curEmail=currentList.textEmailVal
        val curTradingName=currentList.textTradingNameVal
        val curPhoneNumber=currentList.textPhoneNumberVal
        val curLocation=currentList.textLocationVal
        val curBusinessCertificationNumber=currentList.textBusinessCertificationNumberVal
        val curDateOfRegistration=currentList.textDateOfRegistrationVal

        val editView=LayoutInflater.from(activity).inflate(R.layout.fragment_edit_taxpayer,null)
        //set current taxpayer values to input box
        val emailValueText=editView.findViewById<TextInputEditText>(R.id.emailEditTextTaxpayerUpdate)
        val tradingNameValueText=editView.findViewById<TextInputEditText>(R.id.tradingNameEditTextTaxpayerUpdate)
        val phoneNumberValueText=editView.findViewById<TextInputEditText>(R.id.phoneNumberEditTextTaxpayerUpdate)
        val locationValueText=editView.findViewById<TextInputEditText>(R.id.locationEditTextTaxpayerUpdate)
        val businessCertificationNumberValueText=editView.findViewById<TextInputEditText>(R.id.businessCertificationNumberEditTextTaxpayerUpdate)
        val dateOfRegistrationValueText=editView.findViewById<TextInputEditText>(R.id.dateOfRegistrationEditTextTaxpayerUpdate)
        val tPinValueText=editView.findViewById<TextInputEditText>(R.id.tPinEditTextTaxpayerUpdate)

        emailValueText.text=Editable.Factory.getInstance().newEditable(curEmail)
        tradingNameValueText.text=Editable.Factory.getInstance().newEditable(curTradingName)
        phoneNumberValueText.text=Editable.Factory.getInstance().newEditable(curPhoneNumber)
        locationValueText.text=Editable.Factory.getInstance().newEditable(curLocation)
        businessCertificationNumberValueText.text=Editable.Factory.getInstance().newEditable(curBusinessCertificationNumber)
        dateOfRegistrationValueText.text=Editable.Factory.getInstance().newEditable(curDateOfRegistration)
        tPinValueText.text=Editable.Factory.getInstance().newEditable(curTpin)

        MaterialAlertDialogBuilder(requireActivity())
            .setView(editView)
            .setTitle("Edit Taxpayer: $curTpin")

            .setNegativeButton("Cancel"){dialog,which->

            }
            .setPositiveButton("Update"){dialog,which->

                val editTaxpayerDetails= CreateEditData(
                    //taxpayerTpin = bindingEdit.tPinEditTextTaxpayerUpdate.text.toString(),
                    taxpayerTpin=tPinValueText.text.toString(),
                    taxpayerBusinessCertificateNumber =businessCertificationNumberValueText.text.toString(),
                    taxpayerTradingName = tradingNameValueText.text.toString(),
                    taxpayerBusinessRegistrationDate = dateOfRegistrationValueText.text.toString(),
                    taxpayerMobileNumber = phoneNumberValueText.text.toString(),
                    taxpayerEmail = emailValueText.text.toString(),
                    taxpayerPhysicalLocation = locationValueText.text.toString(),
                    taxpayerUsername = userID)


                updateTaxpayerDetails(editTaxpayerDetails)

            }
            .show()



    }



    private fun updateTaxpayerDetails(editTaxpayerDetails: CreateEditData) {
        //var t1=bindingEdit.tPinContainerTaxpayerUpdate.helperText
        //var t2=bindingEdit.businessCertificationNumberContainerTaxpayerUpdate.helperText
        //var t3=bindingEdit.emailContainerTaxpayerUpdate.helperText
        //var t4=bindingEdit.tradingNameContainerTaxpayerUpdate.helperText
        //var t5=bindingEdit.locationContainerTaxpayerUpdate.helperText
        //var t6=bindingEdit.dateOfRegistrationContainerTaxpayerUpdate.helperText
        //var t7=bindingEdit.phoneNumberContainerTaxpayerUpdate.helperText

        editTaxpayerTOAPI(editTaxpayerDetails)

       // if (t1==null && t2==null && t3==null&& t4==null&& t5==null&& t6==null&& t7==null ){

        //    editTaxpayerTOAPI()

       // }else{
        //    Toast.makeText(activity,"click on validate before submitting", Toast.LENGTH_SHORT).show()
        //}

    }

    private fun editTaxpayerTOAPI(editTaxpayerDetails:CreateEditData) {
       // val editTaxpayerDetails= CreateEditData(
           // taxpayerTpin = bindingEdit.tPinEditTextTaxpayerUpdate.text.toString(),
            //taxpayerBusinessCertificateNumber =bindingEdit.businessCertificationNumberEditTextTaxpayerUpdate.text.toString(),
           // taxpayerTradingName = bindingEdit.tradingNameEditTextTaxpayerUpdate.text.toString(),
           // taxpayerBusinessRegistrationDate = bindingEdit.dateOfRegistrationEditTextTaxpayerUpdate.text.toString(),
           // taxpayerMobileNumber = bindingEdit.phoneNumberEditTextTaxpayerUpdate.text.toString(),
           // taxpayerEmail = bindingEdit.emailEditTextTaxpayerUpdate.text.toString(),
           // taxpayerPhysicalLocation = bindingEdit.locationEditTextTaxpayerUpdate.text.toString(),
            //taxpayerUsername = "ychitungu@gmail.com")

        //val e3=binding.ttt


        //e3.text= editTaxpayerDetails.toString()


        mService.editTaxpayer(editTaxpayerDetails)
            .enqueue(object:Callback<EditTaxpayerAPIResponse>{//uses <CreateTaxpayerAPIResponse> since it has same variables
                override fun onResponse(
                    call: Call<EditTaxpayerAPIResponse>,
                    response: Response<EditTaxpayerAPIResponse>
                ) {

                binding.swipeRefreshId.isRefreshing=true
                refreshHomePageData()
                binding.recyclerView.adapter?.notifyDataSetChanged()
                binding.swipeRefreshId.isRefreshing=false
                when(response.code().toString()){
                    "200" ->Toast.makeText(activity,"taxpayer successfully updated", Toast.LENGTH_SHORT).show()
                    "400" ->Toast.makeText(activity,"username does not exist or invalid request", Toast.LENGTH_SHORT).show()
                    else ->Toast.makeText(activity,"unable to update taxpayer", Toast.LENGTH_SHORT).show()

                }
                //Toast.makeText(activity,"refreshing data", Toast.LENGTH_SHORT).show()
                //startActivity(Intent(activity,NavigationDrawer::class.java))


                }

                override fun onFailure(call: Call<EditTaxpayerAPIResponse>, t: Throwable) {
                    Toast.makeText(activity,t.message, Toast.LENGTH_SHORT).show()
                }

            } )
    }


    private fun confirmDelete(view: View,currentList: HomeItem){
    var deleteCurTpin=currentList.textTpinVal
    MaterialAlertDialogBuilder(requireActivity())
        .setTitle("Confirm Delete of $deleteCurTpin")
        .setMessage("Are you sure you want to delete taxpayer with TPin: $deleteCurTpin from the system")
        .setNegativeButton("No"){dialog,which->

        }
        .setPositiveButton("Yes"){dialog,which->

            deleteTaxpayerPermanently(deleteCurTpin)

            //Toast.makeText(activity,"delete of taxpayer confirmed clicked", Toast.LENGTH_SHORT).show()

        }
        .show()
}

    private fun deleteTaxpayerPermanently(deleteCurTpin:String) {
        val deleteTpinValue=DeleteTaxpayerData(taxpayerTpin = deleteCurTpin)
        mService.deleteTaxpayer(deleteTpinValue)
            .enqueue(object :Callback<DeleteTaxpayerAPIResponse>{
                override fun onResponse(
                    call: Call<DeleteTaxpayerAPIResponse>,
                    response: Response<DeleteTaxpayerAPIResponse>
                ) {
                    when(response.code().toString()){
                        "200" ->Toast.makeText(activity,"taxpayer $deleteCurTpin deleted successfully", Toast.LENGTH_SHORT).show()
                        "500" ->Toast.makeText(activity,"Error while deleting $deleteCurTpin", Toast.LENGTH_SHORT).show()
                        else ->Toast.makeText(activity,"unable to delete $deleteCurTpin", Toast.LENGTH_SHORT).show()

                    }

                    //startActivity(Intent(activity,NavigationDrawer::class.java))
                    binding.swipeRefreshId.isRefreshing=true
                    refreshHomePageData()
                    binding.recyclerView.adapter?.notifyDataSetChanged()
                    binding.swipeRefreshId.isRefreshing=false

                }

                override fun onFailure(call: Call<DeleteTaxpayerAPIResponse>, t: Throwable) {
                    Toast.makeText(activity,"taxpayer $deleteCurTpin deleted successfully", Toast.LENGTH_SHORT).show()
                    //Toast.makeText(activity,t.message, Toast.LENGTH_SHORT).show()
                    //startActivity(Intent(activity,NavigationDrawer::class.java))
                    pullRefreshLayoutData()

                }

            })
    }

    private fun generateList():List<HomeItem>{


   return getTaxpayersFromAPI()

}

    private fun getTaxpayersFromAPI(): ArrayList<HomeItem> {
        val list=ArrayList<HomeItem>()
        //Toast.makeText(activity,"connectingggggggggg", Toast.LENGTH_LONG).show()
        mService.getTaxpayers()
            .enqueue(object:Callback<List<GetAllTaxpayersAPIResponse>>{
                override fun onResponse(
                    call: Call<List<GetAllTaxpayersAPIResponse>>,
                    response: Response<List<GetAllTaxpayersAPIResponse>>
                ) {
                    //Toast.makeText(activity,"connected", Toast.LENGTH_LONG).show()
                    //val e2=binding.xemail2
                    ///val e3=binding.xemail3


                    //e2.text= Editable.Factory.getInstance().newEditable(response.body()?.get(1)?.TradingName.toString())
                    //e3.text= Editable.Factory.getInstance().newEditable(response.body()?.size.toString())

                    //Toast.makeText(activity, response.toString(), Toast.LENGTH_LONG).show()
                    //Toast.makeText(activity, response.body().toString(), Toast.LENGTH_LONG).show()
                    //Toast.makeText(activity, response.body()?.taxpayers.toString(), Toast.LENGTH_LONG).show()
                    var tpinv: String? = "00000000"
                    var emailv: String? = "00000000"
                    var tradingNamev: String? = "00000000"
                    var locationv: String? = "00000000"
                    var phoneNumberv: String? = "00000000"
                    var businessCertNumv: String? = "00000000"
                    var dateOfRegv: String? = "00000000"
                    val drawable = R.drawable.mra_logo

                    if (response.code() == 200) {

                        //var item:HomeItem?=null

                        //while loop
                        var counter = 0
                        //Toast.makeText(activity,"retriving data", Toast.LENGTH_LONG).show()

                        while (counter < response.body()?.size!!) {

                            var tpinv = response.body()?.get(counter)?.TPIN.toString()
                            var emailv = response.body()?.get(counter)?.Email.toString()
                            var tradingNamev = response.body()?.get(counter)?.TradingName.toString()
                            var locationv = response.body()?.get(counter)?.PhysicalLocation.toString()
                            var phoneNumberv = response.body()?.get(counter)?.MobileNumber.toString()
                            var businessCertNumv = response.body()?.get(counter)?.BusinessCertificateNumber.toString()
                            var dateOfRegv = response.body()?.get(counter)?.BusinessRegistrationDate.toString()


                                var item = HomeItem(
                                    drawable,
                                    tpinv,
                                    emailv,
                                    tradingNamev,
                                    locationv,
                                    phoneNumberv,
                                    businessCertNumv,
                                    dateOfRegv
                                )
                                counter++
                                list += item




                        }

                    }


                }

                override fun onFailure(call: Call<List<GetAllTaxpayersAPIResponse>>, t: Throwable) {


                    Toast.makeText(activity,t.message, Toast.LENGTH_SHORT).show()

                }

            })

        return list
    }

    companion object {
    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    @JvmStatic
    fun newInstance(param1: String, param2: String) =
        HomeFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_PARAM1, param1)
                putString(ARG_PARAM2, param2)
            }
        }
}
}