package com.example.mraapp.Model

class EditTaxpayerAPIResponse {
    var ResultCode:Int?=1
    var Remark:String?=null
    var data: String?=null

}