package com.example.mraapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.Toast
import androidx.annotation.Keep
import com.example.mraapp.Common.Common
import com.example.mraapp.Model.APIResponse
import com.example.mraapp.Remote.IMyAPI
import com.example.mraapp.databinding.ActivityMainBinding
import com.google.android.material.textfield.TextInputEditText
import com.google.gson.annotations.SerializedName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.encodeToJsonElement

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    internal lateinit var mService: IMyAPI
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        //setContentView(R.layout.activity_main)

        //initialize the service
        mService= Common.api

        //event listener
        binding.txtRegister.setOnClickListener {
            Toast.makeText(this@MainActivity,"Featured coming soon", Toast.LENGTH_SHORT).show()
            //startActivity(Intent(this@MainActivity,RegisterActivity::class.java))
            }
        binding.forgotPassword.setOnClickListener {
            Toast.makeText(this@MainActivity,"Featured coming soon", Toast.LENGTH_SHORT).show()

        }

        //enable this below to authenticate user using api
        binding.btnLogin.setOnClickListener{
            Toast.makeText(this@MainActivity,"Authenticating please wait...", Toast.LENGTH_SHORT).show()

            authenticateUser(binding.email.text.toString(),binding.password.text.toString())}

        //binding.btnLogin.setOnClickListener{Toast.makeText(this@MainActivity,"login wwwwwwwwwsuccessfully",Toast.LENGTH_SHORT).show() }
        //binding.btnLogin.setOnClickListener{ startActivity(Intent(this@MainActivity,NavigationDrawer::class.java)) }

    }
    //@Keep
    //@Serializable
    data class UserData(
        @SerializedName("Email") val userEmail:String?,
        @SerializedName("Password")val userPassword:String?)

    private fun authenticateUser(email: String, password: String){
        val userLogIn=UserData(
            userEmail = email,
            userPassword = password
        )
        //Toast.makeText(this@MainActivity,json, Toast.LENGTH_SHORT).show()
        mService.loginUser(userLogIn)
            .enqueue(object: Callback<APIResponse> {
                override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                    Toast.makeText(this@MainActivity,t.message, Toast.LENGTH_SHORT).show()
                }

                override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                    if (response.body()!!.Authenticated==true){
                        Toast.makeText(this@MainActivity, response.body()!!.Remark, Toast.LENGTH_SHORT).show()

                        val i =Intent(this@MainActivity,NavigationDrawer::class.java)
                        //Toast.makeText(this@MainActivity,response.body()!!.UserDetails?.contains("Username").toString(), Toast.LENGTH_SHORT).show()
                        //Toast.makeText(this@MainActivity,response.body()!!.UserDetails?.get("Username").toString(), Toast.LENGTH_SHORT).show()
                        i.putExtra("UserID", response.body()!!.UserDetails?.get("Username").toString())
                        i.putExtra("firstName",response.body()!!.UserDetails?.get("FirstName").toString())
                        i.putExtra("lastName",response.body()!!.UserDetails?.get("LastName").toString())
                        startActivity(i)


                    }else{
                        Toast.makeText(this@MainActivity,response.body()!!.Remark, Toast.LENGTH_SHORT).show()

                    }

                    //val emailValueText=binding.email
                    //val passValueText=binding.password

                    //emailValueText.text= Editable.Factory.getInstance().newEditable(response.toString())
                    //emailValueText.text= Editable.Factory.getInstance().newEditable(response.body()!!.UserDetails.toString())
                        //Toast.makeText(this@MainActivity,response.errorBody().toString(), Toast.LENGTH_LONG).show()
                        //Toast.makeText(this@MainActivity,response.body().toString(), Toast.LENGTH_LONG).show()

                }
            })


    }
}
